
			<footer>
				<div class="row footer-container">
					<div class="col col-sm-3 col-xs-6">
						<a href="https://www.facebook.com/AAUEvora/" target="blank">
							<img class="logoaaue-footer" src="<?php echo base_url()?>assets/imgs/logoaaue.svg">
						</a>
					</div>
					<div class="col col-sm-6 hidden-xs texto-footer">
						<p>
							Associação Académica da Universidade de Évora
						</p>
						<p>
							Queima das Fitas 2017
						</p>
					</div>

					<div class="col col-sm-3 col-xs-6 redes-sociais-container">
						<div class="redes-sociais">
							<font size="2">
								SEGUE-NOS:<br>
							</font>
							<a href="https://www.facebook.com/queimadasfitasevora" target="blank">
							<img class="logofacebook" src="<?php echo base_url()?>assets/imgs/facebook.svg" ></a>
							<a href="https://www.instagram.com/aauevora/" target="blank">
							<img class="logoinstagram" src="<?php echo base_url()?>assets/imgs/insta.svg"></a>
						</div>
					</div>
				</div>
			</footer>
		<div class="site-cache" id="site-cache"></div>
	</div> <!-- END site-pusher -->
</div> <!-- END site-container -->

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="<?php echo base_url()?>assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url()?>assets/js/counter.js"></script>
<script src="<?php echo base_url()?>assets/js/header.js"></script>

</body>
</html>
