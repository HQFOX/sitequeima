<div class="cartaz-container">
<!-- 	<h1>BREVEMENTE</h1> -->
	<img style="height: 100%;" src="<?php echo base_url()?>assets/imgs/cartaz.svg">
</div>
