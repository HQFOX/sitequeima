<div >
  <div class="row">
    <div class="col col-sm-5 hidden-xs">
      <div >
        <img class="precos-logoqueima" src="<?php echo base_url() ?>assets/imgs/logoqueima.svg">
      </div>
    </div>
    <div class="col col-sm-2 precos-passesgerais">
      <h2 style="color: #1c3761"><b>Passes Gerais</b></h2>
      <br>
      <h4>SÓCIO / BOLSEIRO</h4>
      <h3 style="color: #1c3761">35€</h3>
      <br>
      <h4>ESTUDANTE UNIVERSITÁRIO / FUNCIONÁRIO UE</h4>
      <h3 style="color: #1c3761">55€</h3>
      <br>
      <h4>NÃO ESTUDANTE</h4>
      <h3 style="color: #1c3761">65€</h3>
    </div>

    <div class="col col-sm-5 precos-passesdiarios">
      <div class="row">
         <h2 style="color: #1c3761;"><b>Passes Diários</b></h2>
      <br>
      </div>

      <div class="row">

        <div class="col col-sm-3">
        </div>
        <div class="col col-sm-3">
          <h4>Sócio / Bolseiro</h4>
        </div>
        <div class="col col-sm-3">
          <h4>Estudante Universitário/
            Funcionário UE</h4>
        </div>
        <div class="col col-sm-3">
          <h4>Não Estudante</h4>
        </div>
      </div>
      <div class="row">

        <div class="col col-sm-3">
          <h4>Dia 26 </h4>
          <h4>Dia 27 </h4>
          <h4>Dia 28 </h4>
          <h4>Dia 29 </h4>
          <h4>Dia 30 </h4>
          <h4>Dia 31 </h4>
          <h4>Dia 1 &nbsp;</h4>
          <h4>Dia 2 &nbsp;</h4>
          <h4>Dia 3 &nbsp;</h4>
        </div>

        <div class="col col-sm-3" style="color: #1c3761;">
          <h4>GRATUITO</h4>
          <h4>8€</h4>
          <h4>3€</h4>
          <h4>5€</h4>
          <h4>6€</h4>
          <h4>4€</h4>
          <h4>6€</h4>
          <h4>8€</h4>
          <h4>8€</h4>
        </div>

        <div class="col col-sm-3" style="color: #1c3761;">
          <h4>GRATUITO</h4>
          <h4>9€</h4>
          <h4>4€</h4>
          <h4>7€</h4>
          <h4>8€</h4>
          <h4>5€</h4>
          <h4>8€</h4>
          <h4>9€</h4>
          <h4>9€</h4>
        </div>

        <div class="col col-sm-3" style="color: #1c3761;">
          <h4>GRATUITO</h4>
          <h4>13€</h4>
          <h4>6€</h4>
          <h4>9€</h4>
          <h4>10€</h4>
          <h4>7€</h4>
          <h4>10€</h4>
          <h4>13€</h4>
          <h4>11€</h4>
        </div>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col col-md-6 precos-notas">
      <p><h6>* Não Estudante: Tens que ter mais de 16 anos e fazer-te acompanhar de cartão de cidadão</h6></p>
      <p><h6>* Estudante Universitário: Cartão da Universidade atualizado e C.C. No caso de ser aluno da UE basta aceder ao SIIUE</h6></p>
      <p><h6>* Sócio: Cartão de Sócio com as quotas em dia e o C.C.</h6></p>
      <p><h6>* Bolseiro: Cartão de Cidadão</h6></p>
      <p><h6>* Erasmus: Cartão de Erasmus</h6></p>
    </div>
  </div>
</div>
