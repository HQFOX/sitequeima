<div style="height: calc(70% - 100px); width: 100%; " align="center">
	<img style="margin-top: 30px; height: 100%; width: 40%;" src="<?php echo base_url() ?>assets/imgs/logoqueima.svg">
</div>

<div id="counter" align="center">

</div>

<div class="row" style="margin: 0">
	<div class="col-xs-6">
		<img style="width: 100%;" src="<?php echo base_url() ?>assets/imgs/barrahome.svg">
	</div>
	<div class="col-xs-6">
		<img style="width: 100%;" src="<?php echo base_url() ?>assets/imgs/barrahome.svg">
	</div>
</div>


<div class="row container-mapa">
	<div>
		<h1 class="texto-mapa">Como Chegar:</h1>
		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1559.621815442177!2d-7.906112341843817!3d38.57423709186002!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzjCsDM0JzI3LjIiTiA3wrA1NCcxOC4xIlc!5e0!3m2!1sen!2spt!4v1494452591426"
				frameborder="0" style="border:0;"
				allowfullscreen></iframe>
		<br>
		<a href="https://www.google.com/maps/place/38%C2%B034'27.3%22N+7%C2%B054'18.6%22W/@38.5742552,-7.9073557,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0x0!8m2!3d38.574251!4d-7.905167?hl=en-US"
		   target="blank" class="maparecinto">
			 <h1 class="texto-mapa">
				 Mapa do Recinto
			</h1>
		</a>
	</div>
</div>
